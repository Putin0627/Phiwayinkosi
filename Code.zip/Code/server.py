# server.py
import socket
import threading

# Shared dictionary and lock for thread safety
dictionary = {}
lock = threading.Lock()

def handle_client(client_socket):
    try:
        while True:
            # Receive the request from the client
            request = client_socket.recv(1024).decode('utf-8')
            if not request:
                break

            # Parse the client's request (expecting: "command word [definition]")
            parts = request.strip().split(' ', 2)
            command = parts[0].lower()

            if len(parts) < 2:
                response = "Invalid request format. Use: command word [definition]"
            else:
                word = parts[1]
                definition = parts[2] if len(parts) > 2 else ""

                # Use lock for thread safety during dictionary operations
                with lock:
                    if command == 'lookup':
                        # Lookup the word in the dictionary
                        response = dictionary.get(word, f"'{word}' not found in dictionary.")
                    elif command == 'add':
                        if not definition:
                            response = "Add command requires a definition."
                        elif word in dictionary:
                            response = f"'{word}' already exists in dictionary."
                        else:
                            dictionary[word] = definition
                            response = f"'{word}' added successfully."
                    elif command == 'update':
                        if not definition:
                            response = "Update command requires a new definition."
                        elif word in dictionary:
                            dictionary[word] = definition
                            response = f"'{word}' updated successfully."
                        else:
                            response = f"'{word}' not found in dictionary."
                    else:
                        response = "Invalid command. Use 'lookup', 'add', or 'update'."

            # Send the response back to the client
            client_socket.send(response.encode('utf-8'))

    except Exception as e:
        print(f"An error occurred: {e}")
    finally:
        # Close the client connection
        client_socket.close()

def start_server(host='127.0.0.1', port=65432):
    # Create and bind the server socket
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        server.bind((host, port))
    except socket.error as e:
        print(f"Bind failed. Error: {e}")
        return

    server.listen(5)  # Can handle up to 5 clients at a time
    print(f"Server is listening on {host}:{port}...")

    try:
        while True:
            client_socket, addr = server.accept()
            print(f"Connected by {addr}")

            # Create a new thread to handle each client connection
            client_handler = threading.Thread(target=handle_client, args=(client_socket,))
            client_handler.start()
    except KeyboardInterrupt:
        print("\nServer is shutting down.")
    finally:
        server.close()

if __name__ == "__main__":
    start_server()
