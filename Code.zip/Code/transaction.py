import threading
import socket

# Assuming you have an existing dictionary
dictionary = {}

# Lock for dictionary operations
dictionary_lock = threading.Lock()


def handle_client(conn, addr):
    print(f"Connection from {addr}")

    while True:
        try:
            data = conn.recv(1024).decode()
            if not data:
                break

            command, *args = data.split()

            # Ensure atomicity with lock
            with dictionary_lock:
                if command == 'add':
                    word, definition = args[0], " ".join(args[1:])
                    if word in dictionary:
                        response = f"'{word}' already exists."
                    else:
                        dictionary[word] = definition
                        response = f"'{word}' added successfully."

                elif command == 'update':
                    word, new_definition = args[0], " ".join(args[1:])
                    if word in dictionary:
                        dictionary[word] = new_definition
                        response = f"'{word}' updated successfully."
                    else:
                        response = f"'{word}' not found."

                elif command == 'lookup':
                    word = args[0]
                    response = f"'{word}': {dictionary.get(word, 'not found')}."
                else:
                    response = "Invalid command."

        except Exception as e:
            response = f"Error: {str(e)}"

        conn.send(response.encode())

    conn.close()
