# client_program.py
import socket

def client_program():
    host = '127.0.0.1'  # The server's IP address
    port = 65432         # The server's port

    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        client_socket.connect((host, port))
    except ConnectionRefusedError:
        print(f"Cannot connect to server at {host}:{port}. Make sure the server is running.")
        return

    try:
        while True:
            # Input command from the user (lookup, add, update)
            request = input("Enter command (lookup/add/update) followed by word and definition (if needed), or 'exit' to quit: ")
            if not request:
                continue

            if request.lower() == 'exit':
                print("Exiting client.")
                break

            # Send the request to the server
            try:
                client_socket.send(request.encode('utf-8'))
            except BrokenPipeError:
                print("Connection to server lost.")
                break

            # Receive the response from the server
            response = client_socket.recv(1024).decode('utf-8')
            print(f"Server response: {response}")
    finally:
        # Close the client connection when done
        client_socket.close()

if __name__ == "__main__":
    client_program()
